﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Ingredient
    {
        public string Name { get; set; }
        public int Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Ingredient> ingredients = new List<Ingredient>();

            Console.WriteLine("Enter the number of ingredients");
            int num_ingredients = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < num_ingredients; i++)
            {
                Ingredient ingredient = new Ingredient();

                Console.WriteLine("Enter the name of the ingredient");
                ingredient.Name = Console.ReadLine();

                Console.WriteLine("Enter the quantity of the ingredient");
                ingredient.Quantity = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the unit of the ingredient");
                ingredient.Unit = Console.ReadLine();

                Console.WriteLine("Enter the number of calories for the ingredient");
                ingredient.Calories = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the food group of the ingredient");
                ingredient.FoodGroup = Console.ReadLine();

                ingredients.Add(ingredient);
            }

            Console.WriteLine("Enter the number of steps");
            int num_steps = Convert.ToInt32(Console.ReadLine());
            string[] steps = new string[num_steps];

            for (int i = 0; i < num_steps; i++)
            {
                Console.WriteLine("Enter the description of step {0}", i + 1);
                steps[i] = Console.ReadLine();
            }

            Console.WriteLine("Enter the factor by which you want to scale the recipe");
            int factor = Convert.ToInt32(Console.ReadLine());

            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }

            Console.WriteLine("Enter the factor by which you want to reset the recipe");
            factor = Convert.ToInt32(Console.ReadLine());

            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.Quantity /= factor;
            }

            Console.WriteLine("Enter the factor by which you want to clear the recipe");
            factor = Convert.ToInt32(Console.ReadLine());

            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.Quantity = 0;
            }

            Console.WriteLine("Enter the name of the recipe");
            string recipeName = Console.ReadLine();

            Console.WriteLine("\nRecipe: {0}", recipeName);

            int totalCalories = 0;

            foreach (Ingredient ingredient in ingredients)
            {
                Console.WriteLine("{0} {1} {2}", ingredient.Name, ingredient.Quantity, ingredient.Unit);
                totalCalories += ingredient.Calories * ingredient.Quantity;
            }

            Console.WriteLine("Total Calories: {0}", totalCalories);

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Total calories exceed 300!");
            }

            Console.WriteLine("\nSteps:");

            for (int i = 0; i < num_steps; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, steps[i]);
            }


            Console.WriteLine("\nList of recipes:");
            List<string> recipeNames = new List<string>();
            foreach (Ingredient ingredient in ingredients)
            {
                if (!recipeNames.Contains(ingredient.Name))
                {
                    recipeNames.Add(ingredient.Name);
                }
            }
            recipeNames.Sort();

            foreach (string name in recipeNames)
            {
                Console.WriteLine(name);
            }
        }
    }
}
            
